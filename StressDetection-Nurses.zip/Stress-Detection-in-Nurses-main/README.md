# Stress-Detection-in-Nurses

The notebook (predictor.ipynb) contains the code sections for data pre-processing, feature extraction, modeling and event detection.

The repository contains a sample subject data folder, as well as the conda and pip environment files.

With Anaconda installed, create the code environment with:

conda env create -f environment.yml
